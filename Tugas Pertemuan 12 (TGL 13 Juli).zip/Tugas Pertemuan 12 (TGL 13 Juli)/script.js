function appendValue(val) {
  document.getElementById("display").value += val;
}

function clearDisplay() {
  document.getElementById("display").value = "";
}

function calculate() {
  let display = document.getElementById("display");
  let value = display.value;

  if (value.includes("%")) {
    let percentValue = value.replace("%", "");
    try {
      let result = eval(percentValue) / 100;
      display.value = result;
    } catch (e) {
      display.value = "Error";
    }
  } else {
    try {
      let result = eval(value);
      display.value = result;
      if (result < 0) {
        display.classList.add("negative");
      } else {
        display.classList.remove("negative");
      }
    } catch (e) {
      display.value = "Error";
      display.classList.remove("negative");
    }
  }
}
